RILL Chapters Suite
- Tag books with: chapters_cook (Product Tag)
- Use shortcode: [rill_book_toc] on book or chapter template
- Parts: Chapters > TOC Builder
